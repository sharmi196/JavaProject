package com.example.OTT.Managemant.System;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OttManagemantSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
