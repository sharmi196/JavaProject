package com.example.OTT.Managemant.System;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OttManagemantSystemApplication {

	public static void main(String[] args) {
		SpringApplication.run(OttManagemantSystemApplication.class, args);
	}

}
