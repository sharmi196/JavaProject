package com.example.HotelBooking;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelBookingApplicationTests {

	@Test
	void contextLoads() {
	}

}
